# Mi Sitio — GitHub Pages

Landing page mínima para publicar en **GitHub Pages**.

## Pasos rápidos

1. Crea un repositorio nuevo en GitHub (por ejemplo, `mi-sitio`).
2. Sube los archivos de este ZIP al repositorio (incluyendo `index.html` y la carpeta `assets/`).
3. Ve a **Settings → Pages** y en **Build and deployment** elige **Deploy from a branch**.
4. Selecciona la rama `main` y la carpeta `/root`, guarda.
5. Tu sitio quedará disponible en: `https://TU-USUARIO.github.io/mi-sitio/`.

> Si quieres que sea un “user site”, nombra el repo exactamente `TU-USUARIO.github.io` (sin carpeta).

## Editar contenido

- Cambia textos en `index.html` (secciones Servicios, Sobre mí, Contacto).
- Reemplaza `tu-email@ejemplo.com` por tu correo real.
- Personaliza colores en `assets/style.css`.

¡Listo!
